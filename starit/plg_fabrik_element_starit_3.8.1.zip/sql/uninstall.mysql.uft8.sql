DROP TABLE IF EXISTS `#__fabrik_starit`;
